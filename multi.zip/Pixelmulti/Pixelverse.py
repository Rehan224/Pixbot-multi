import requests
import json
from time import sleep
from colorama import Fore, Back, Style
import hmac
import hashlib
import time

class UserPixel:
    def __init__(self, config):
        self.config = config

        try:
            self.headers = {
                "user-agent": "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0",
                "secret": self.config['secret'],
                "tg-id": self.config['tgId'],
                "initData": self.config['initData']
            }
        except KeyError as e:
            print(f"Missing key in config file: {e}")
            raise

    # Constructor dan metode lain

    def claim_daily(self):
        url = 'https://api-clicker.pixelverse.xyz/api/daily-rewards'
        headers = self.prepare_headers()
        res = requests.get(url, headers=headers)
        if res.json().get('todaysRewardAvailable'):
            url_claim = 'https://api-clicker.pixelverse.xyz/api/daily-rewards/claim'
            res = requests.post(url_claim, headers=headers)
            amount = res.json().get('amount', 'N/A')
            print(f'Success claim today reward: {amount}')
        else:
            print('Already claimed today reward!')

    def claim_mining(self):
        url = "https://api-clicker.pixelverse.xyz/api/mining/progress"
        headers = self.prepare_headers()
        res = requests.get(url, headers=headers)

        if res.text:
            response_json = res.json()
            available = response_json.get('currentlyAvailable', 0)
            min_claim = response_json.get('minAmountForClaim', float('inf'))
            print(f'Amount available: {available}')

            if available > min_claim:
                url_claim = 'https://api-clicker.pixelverse.xyz/api/mining/claim'
                res = requests.post(url_claim, headers=headers)
                claim_response = res.json()
                claim_amount = claim_response.get('claimedAmount', 'N/A')
                print(f'Claim amount: {claim_amount}')
            else:
                print('Amount too small to claim!')
        else:
            print('Empty response from mining progress API.')

    def auto_buy_pet(self):
        url = 'https://api-clicker.pixelverse.xyz/api/pets/buy'
        headers = self.prepare_headers()
        res_buy_pet = requests.post(url, headers=headers)
        if res_buy_pet.status_code == 200 or res_buy_pet.status_code == 201:
            buy_pet_data = res_buy_pet.json()
            pet_name = buy_pet_data.get('pet', {}).get('name', 'Unknown')
            print(f'Successfully bought a new pet! You got {pet_name}!')
        else:
            print('Not yet time to buy another pet or insufficient points') 

    def claim(self):
        url = "https://api-clicker.pixelverse.xyz/api/mining/claim"
        req = requests.post(url, headers=self.headers)
        data = req.json()
        print(f"Claimed {Back.YELLOW + Fore.BLACK}{int(data['claimedAmount'])}{Style.RESET_ALL} coins !")

    def getUser(self):
        url = "https://api-clicker.pixelverse.xyz/api/users"
        req = requests.get(url, headers=self.headers)
        return req.json()

    def upgrade(self, petId: str):
        url = f"https://api-clicker.pixelverse.xyz/api/pets/user-pets/{petId}/level-up"
        req = requests.post(url, headers=self.headers)
        data = req.json()
        return data

    def upgradePets(self):
        print(f"{self.space}> Checking pets to upgrade ...")
        data = self.getUser()
        currBalance = data['clicksCount']
        petsUrl = "https://api-clicker.pixelverse.xyz/api/pets"
        req = requests.get(petsUrl, headers=self.headers)
        data = req.json()
        pets = data['data']

        for pet in pets:
            if currBalance >= pet['userPet']['levelUpPrice']:
                self.upgrade(pet['userPet']['id'])
                print(f"{self.space}> Sucessfully {Style.BRIGHT}upgraded{Style.RESET_ALL} pet {Back.YELLOW + Fore.BLACK}{pet['name']}{Style.RESET_ALL}")
                sleep(0.5)

    def getStats(self):
        url = "https://api-clicker.pixelverse.xyz/api/battles/my/stats"
        req = requests.get(url, headers=self.headers)
        return req.json()

    def isBroken(self):
        url = "https://api-clicker.pixelverse.xyz/api/tasks/my"
        req = requests.get(url, headers=self.headers)

    # Menambahkan fungsi prepare_headers
    def prepare_headers(self):
        headers = {
            "user-agent": "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0",
            "secret": self.config['secret'],
            "tg-id": self.config['tgId'],
            "initData": self.config['initData']
        }
        return headers

    # Menambahkan fungsi daily_combo
    def daily_combo(self, id_pets):
        url_current_game = "https://api-clicker.pixelverse.xyz/api/cypher-games/current"
        headers = self.prepare_headers()
        res_current_game = requests.get(url_current_game, headers=headers)

        if res_current_game.status_code == 200 and res_current_game.text:
            game_data = res_current_game.json()
            if game_data['status'] == "ACTIVE":
                game_id = game_data.get('id')
                available_options = game_data.get('options', [])
                pet_id_index_map = {option["optionId"]: len(available_options) - option["order"] - 1 for option in available_options}

                id_pets = [pet_id.strip() for pet_id in id_pets]
                payload = {pet_id: len(id_pets) - id_pets.index(pet_id) - 1 for pet_id in id_pets}

                url_answer = f"https://api-clicker.pixelverse.xyz/api/cypher-games/{game_id}/answer"
                headers['Content-Type'] = 'application/json'
                res_answer = requests.post(url_answer, data=json.dumps(payload), headers=headers)

                if res_answer.status_code == 200 or res_answer.status_code == 201:
                    answer_data = res_answer.json()
                    reward_amount = answer_data.get('rewardAmount', 'N/A')
                    print(f'Successfully submitted the daily combo! Reward Amount: {reward_amount}')
                else:
                    print(f'Failed to submit the daily combo. {res_answer.text}')
            else:
                print('Daily Combo already claimed!')
        else:
            print('Daily Combo Already Claimed!')
