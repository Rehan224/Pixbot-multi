import asyncio
import json
import websockets
import requests
import os
from Battle import Battle
from Pixelverse import UserPixel
from colorama import Fore, Style, init, Back
from time import sleep
from random import randint

def clear():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')

def split_chunk(var):
    n = 3
    var = var[::-1]
    return ' '.join([var[i:i + n] for i in range(0, len(var), n)])[::-1]

async def run_account(account, upgrade_pets):
    user = UserPixel(account)
    battle = Battle(account)
    
    userInfo = user.getUser()
    stats = user.getStats()
    win_percentage = stats['wins'] / stats['battlesCount'] * 100
    message = f"""
{Back.MAGENTA}{Fore.WHITE}PixelBot{Style.RESET_ALL} | Made by {Back.MAGENTA + Fore.WHITE}S1NJED{Style.RESET_ALL}


Logged in as {Style.BRIGHT + Fore.GREEN}{userInfo['username']}{Style.RESET_ALL}{Fore.GREEN + Style.BRIGHT}

{Back.YELLOW + Fore.BLACK}STATS{Style.RESET_ALL}

> {Back.YELLOW + Fore.BLACK}Balance{Style.RESET_ALL}: {Style.BRIGHT}{split_chunk(str(int(userInfo['clicksCount'])))}{Style.RESET_ALL}
> {Back.GREEN}Win Rate {Style.RESET_ALL}: {Style.BRIGHT}{win_percentage:.2f}%{Style.RESET_ALL} 
> {Back.YELLOW + Fore.BLACK}Total Main{Style.RESET_ALL}: {Style.BRIGHT}{split_chunk(str(stats['battlesCount']))}{Style.RESET_ALL}
> {Back.GREEN}Wins{Style.RESET_ALL}: {Style.BRIGHT}{split_chunk(str(stats['wins']))}{Style.RESET_ALL}
> {Back.RED}Loses{Style.RESET_ALL}: {Style.BRIGHT}{split_chunk(str(stats['loses']))}{Style.RESET_ALL}
> {Back.GREEN}Money Won{Style.RESET_ALL}: {Style.BRIGHT}{split_chunk(str(stats['winsReward']))}{Style.RESET_ALL}
> {Back.RED}Money Lost{Style.RESET_ALL}: {Style.BRIGHT}-{split_chunk(str(abs(stats['losesReward'])))}{Style.RESET_ALL}
> {Back.GREEN}Total earned{Style.RESET_ALL}: {Style.BRIGHT}{split_chunk(str(stats['winsReward'] - abs(stats['losesReward'])))}{Style.RESET_ALL}

    """
    print(message)

    try:
        await battle.connect()
    except websockets.exceptions.ConnectionClosed:
        print(f"{battle.space}> Connection closed, retrying in 5 seconds ...")
        sleep(5)
        return

    user.claim()

    if upgrade_pets:
        user.upgradePets()

    timeToWait = randint(5, 10)
    print(f"> Waiting {Back.RED + Fore.WHITE}{timeToWait}{Style.RESET_ALL} seconds.\n")
    await asyncio.sleep(timeToWait)



async def main():
    init()  # colorama

    with open('./config.json', 'r') as file:
        config = json.load(file)

    upgrade_pets = input("Would you like to upgrade pets? (y/n): ").strip().lower() == 'y'

    while True:  # Loop untuk menjalankan akun secara berulang
        clear()
        for index, account in enumerate(config['accounts'], start=1):
            print(f"==================================================\nRunning account {index}/{len(config['accounts'])}")
            try:
                await run_account(account, upgrade_pets)
            except KeyboardInterrupt:
                clear()
                print("                                    > Goodbye :)")
                return
            except Exception as err:

                print("BOT HAS CRASHED :(")

                if 'battle' in locals() and battle is not None:
                    del battle

                if 'user' in locals() and user is not None:
                    pixelverse = UserPixel(account)

                    if pixelverse.isBroken():
                        print(f"Pixelverse seems to be down for the moment, retrying again in 5 minutes ...")
                        sleep(60 * 5)
                    else:
                        print("The problem does not come from the server, try to restart the bot or if the problem persist open a ticket with a screen of this error ...")
                        print(err)

                        print("Trying again in 60 seconds ...")
                        sleep(60)

        # Delay setelah semua akun selesai diproses
        delay_time = 60  # Delay antara 60 hingga 120 detik
        print(f"SEMUA AKUN SUDAH SELESAI, TUNGGU {delay_time} DETIK, BARU MULAI KEMBALI....")
        await asyncio.sleep(delay_time)
        clear()
if __name__ == '__main__':
    asyncio.run(main())
